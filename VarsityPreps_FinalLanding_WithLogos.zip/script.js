
console.log("Varsity Preps landing page loaded with full design.");
